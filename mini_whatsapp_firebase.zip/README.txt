Mini WhatsApp Firebase - Instructions

1. Crée un projet sur https://console.firebase.google.com
2. Active Realtime Database (mode test)
3. Récupère la configuration dans "Paramètres du projet" > "SDK Web"
4. Remplace les valeurs dans script.js, variable firebaseConfig
5. Ouvre index.html dans un navigateur ou héberge sur Netlify / Glitch / GitHub Pages
6. Tape ton pseudo + message, clique sur envoyer
7. Les messages s'affichent en temps réel à tous les utilisateurs connectés

Important: En mode test, la base est publique. Change les règles pour la production.

Bonne discussion !
