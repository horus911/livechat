// 🚨 Remplace cette config par celle de ton projet Firebase
const firebaseConfig = {
  apiKey: "TON_API_KEY",
  authDomain: "TON_PROJET.firebaseapp.com",
  databaseURL: "https://TON_PROJET.firebaseio.com",
  projectId: "TON_PROJET",
  storageBucket: "TON_PROJET.appspot.com",
  messagingSenderId: "TON_ID",
  appId: "TON_APP_ID"
};

firebase.initializeApp(firebaseConfig);

const db = firebase.database();
const messagesRef = db.ref("messages");

function sendMessage() {
  const username = document.getElementById("username").value.trim();
  const message = document.getElementById("message").value.trim();
  if (username && message) {
    messagesRef.push({
      name: username,
      text: message,
      time: Date.now()
    });
    document.getElementById("message").value = "";
  }
}

messagesRef.on("child_added", function(snapshot) {
  const msg = snapshot.val();
  const el = document.createElement("div");
  el.textContent = `${msg.name} : ${msg.text}`;
  document.getElementById("messages").appendChild(el);
  el.scrollIntoView();
});
